<a href="<?php echo e(route('admin.movies.show',$movie->id)); ?>">
    <img  src="<?php echo e($movie->poster_path); ?>" width="150px" height="200px ">
</a>
<?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/movies/data_table/image.blade.php ENDPATH**/ ?>
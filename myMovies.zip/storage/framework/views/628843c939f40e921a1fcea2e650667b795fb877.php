<?php $__currentLoopData = $admin->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h5><span class="badge badge-primary"><?php echo e($role->name); ?></span></h5>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/admins/data_table/roles.blade.php ENDPATH**/ ?>
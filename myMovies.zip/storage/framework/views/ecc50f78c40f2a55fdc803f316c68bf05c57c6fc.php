<?php $__env->startSection('content'); ?>

    <div>
        <h2><?php echo app('translator')->get('movies.movies'); ?></h2>
    </div>

    <ul class="breadcrumb mt-2">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
        <li class="breadcrumb-item"><?php echo app('translator')->get('movies.movies'); ?></li>
    </ul>

    <div class="row">

        <div class="col-md-12">

            <div class="tile shadow">

                <div class="row mb-2">

                    <div class="col-md-12">


                        <?php if(auth()->user()->hasPermission('delete_movies')): ?>
                            <form method="post" action="<?php echo e(route('admin.movies.bulk_delete')); ?>"
                                  style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <input type="hidden" name="record_ids" id="record-ids">
                                <button type="submit" class="btn btn-danger" id="bulk-delete" disabled="true"><i
                                        class="fa fa-trash"></i> <?php echo app('translator')->get('site.bulk_delete'); ?></button>
                            </form><!-- end of form -->
                        <?php endif; ?>

                    </div>

                </div><!-- end of row -->

                <div class="row">

                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="text" id="data-table-search" class="form-control" autofocus
                                   placeholder="<?php echo app('translator')->get('site.search'); ?>">
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <select class="form-control" id="genre">
                                <option value=""><?php echo app('translator')->get("site.all"); ?> <?php echo app('translator')->get("genres.genre"); ?></option>
                                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($genre->id); ?>"<?php echo e($genre->id == request()->genre_id ? 'selected' : ''); ?>> <?php echo e($genre->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6" style="overflow: hidden">
                        <div class="form-group">
                            <select class="form-control" id="actor">
                                <option><?php echo app('translator')->get("site.all"); ?> <?php echo app('translator')->get("actors.actor"); ?></option>
                                <?php if(request()->actor_id): ?>
                                    <option
                                        value="<?php echo e($actor->id); ?>"<?php echo e($actor->id == request()->actor_id ? 'selected' : ''); ?>> <?php echo e($actor->name); ?>

                                    </option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <select class="form-control" id="type">
                                <option value=""><?php echo app('translator')->get("site.all"); ?> <?php echo app('translator')->get("movies.movie"); ?></option>
                                <?php $__currentLoopData = ['now_playing','upcoming']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        value="<?php echo e($type); ?>" <?php echo e($type == request()->type ? 'selected' : ''); ?> ><?php echo app('translator')->get('movies.' . $type); ?>
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                </div><!-- end of row -->

                <div class="row">

                    <div class="col-md-12">

                        <div class="table-responsive">

                            <table class="table datatable" id="movies-table" style="width: 100%;">
                                <thead>
                                <tr>
                                    <th>
                                        <div class="animated-checkbox">
                                            <label class="m-0">
                                                <input type="checkbox" id="record__select-all">
                                                <span class="label-text"></span>
                                            </label>
                                        </div>
                                    </th>
                                    <th><?php echo app('translator')->get('movies.poster'); ?></th>
                                    <th><?php echo app('translator')->get('movies.name'); ?></th>
                                    <th><?php echo app('translator')->get('genres.genre'); ?></th>
                                    <th><?php echo app('translator')->get('movies.vote'); ?></th>
                                    <th><?php echo app('translator')->get('movies.vote_count'); ?></th>
                                    <th><?php echo app('translator')->get('movies.release_date'); ?></th>
                                    <th><?php echo app('translator')->get('site.action'); ?></th>
                                </tr>
                                </thead>
                            </table>

                        </div><!-- end of table responsive -->

                    </div><!-- end of col -->

                </div><!-- end of row -->

            </div><!-- end of tile -->

        </div><!-- end of col -->

    </div><!-- end of row -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script>
        let genreId = "<?php echo e(request()->genre_id); ?>";
        let actorId = "<?php echo e(request()->actor_id); ?>";
        let type = "<?php echo e(request()->type); ?>";

        let moviesTable = $('#movies-table').DataTable({
            dom: "tiplr",
            serverSide: true,
            processing: true,
            "language": {
                "url": "<?php echo e(asset('admin_assets/datatable-/' . app()->getLocale() . '.json')); ?>"
            },
            ajax: {
                url: '<?php echo e(route('admin.movies.data')); ?>',
                data: function (d) {
                    d.genre_id = genreId;
                    d.actor_id = actorId;
                    d.type = type;
                }
            },
            columns: [
                {data: 'record_select', name: 'record_select', searchable: false, sortable: false, width: '1%'},
                {data: 'poster', name: 'poster', searchable: false, width: '10%'},
                {data: 'title', name: 'title', width: '15%'},
                {data: 'genres', name: 'genres'},
                {data: 'vote', name: 'vote', searchable: false},
                {data: 'vote_Count', name: 'vote_Count', searchable: false},
                {data: 'release_date', name: 'release_date', searchable: false},
                {data: 'actions', name: 'actions', searchable: false, sortable: false, width: '20%'},
            ],
            order: [[4, 'desc']],
            drawCallback: function (settings) {
                $('.record__select').prop('checked', false);
                $('#record__select-all').prop('checked', false);
                $('#record-ids').val();
                $('#bulk-delete').attr('disabled', true);
            }
        });

        // on change genre
        $('#genre').on('change', function () {
            genreId = this.value;
            moviesTable.ajax.reload();
        });


        // on change actor
        $('#actor').on('change', function () {
            actorId = this.value;
            moviesTable.ajax.reload();
        });

        // on change type
        $('#type').on('change', function () {
            type = this.value;
            moviesTable.ajax.reload();
        });


        $('#data-table-search').keyup(function () {
            moviesTable.search(this.value).draw();
        });


        $('#actor').select2({
            ajax: {
                url: '<?php echo e(route('admin.actors.index')); ?>',
                dataType: 'json',
                data: function (params) {
                    return {
                        search: params.term,

                    }

                },
                processResults: function (data) {
                    return {
                        results: data
                    }

                }
            }
        });


    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/movies/index.blade.php ENDPATH**/ ?>
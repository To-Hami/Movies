

<?php $__env->startSection('content'); ?>

    <div>
        <h2><?php echo app('translator')->get('users.edit_profile'); ?></h2>
    </div>

    <ul class="breadcrumb mt-2">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
        <li class="breadcrumb-item"><?php echo app('translator')->get('users.edit_profile'); ?></li>
    </ul>

    <div class="row">

        <div class="col-md-12">

            <div class="tile shadow">

                <form method="post" action="<?php echo e(route('admin.profile.update')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>

                    <?php echo $__env->make('admin.partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('users.name'); ?></label>
                        <input type="text" name="name" class="form-control" value="<?php echo e(old('name', auth()->user()->name)); ?>" required>
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('users.email'); ?></label>
                        <input type="email" name="email" class="form-control" value="<?php echo e(old('email', auth()->user()->email)); ?>" required>
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('users.image'); ?> <span class="text-danger">*</span></label>
                        <input type="file" name="image" class="form-control load-image">
                        <img src="<?php echo e(auth()->user()->image_path); ?>" class="loaded-image" alt="" style="display: block; width: 200px; margin: 10px 0;">
                    </div>

                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-edit"></i> <?php echo app('translator')->get('site.edit'); ?></button>
                    </div>

                </form><!-- end of form -->

            </div><!-- end of tile -->

        </div><!-- end of col -->

    </div><!-- end of row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/profile/edit.blade.php ENDPATH**/ ?>
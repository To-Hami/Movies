<?php $__env->startSection('content'); ?>

    <div>
        <h2><?php echo app('translator')->get('movies.movies'); ?></h2>
    </div>

    <ul class="breadcrumb mt-2">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.movies.index')); ?>"><?php echo app('translator')->get('movies.movies'); ?></a></li>
        <li class="breadcrumb-item"><?php echo app('translator')->get('site.show'); ?></li>
    </ul>

    <div class="row">

        <div class="col-md-12">

            <div class="tile shadow">

                <div class="row">
                    <div class="col-md-2">
                        <img src="<?php echo e($movie->poster_path); ?>" class="img-fluid img-thumbnail">
                    </div>
                    <div class="col-md-10">
                        <h3><?php echo e($movie->title); ?></h3>


                        <?php $__currentLoopData = $movie->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class=" btn btn-primary btn-sm"><?php echo e($genre->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <p style="font-size: 20px"><?php echo e($movie->description); ?></p>

                        <div class="d-flex">
                            <i class="fa fa-star text-warning" style="font-size: 30px"></i>
                            <h3 class="mx-2"><?php echo e($movie->vote); ?></h3>
                            <p class="align-self-center"
                               style="margin-bottom: 0"><?php echo app('translator')->get('movies.by'); ?> <?php echo e($movie->vote_Count); ?></p>
                        </div>

                        <p><span style="font-weight: bold"><?php echo app('translator')->get('movies.language'); ?> :  </span>En</p>
                        <p><span
                                style="font-weight: bold"><?php echo app('translator')->get('movies.release_date'); ?> :  </span><?php echo e($movie->release_date ->format('D-M-Y')); ?>

                        </p>

                        <hr>

                        <span class=" btn btn-primary btn-sm">Images</span>

                        <div class="row image_path">

                            <?php $__currentLoopData = $movie->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-md-3">
                                    <a href="<?php echo e($image->image_path); ?>">
                                        <img src="<?php echo e($image->image_path); ?>" class="img-fluid my-2 img-thumbnail">

                                    </a>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <hr>
                        <span class=" btn btn-primary btn-sm">Actors</span>

                        <div class="row image_path">
                            <?php $__currentLoopData = $movie->actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-md-3">
                                    <?php if($actor ->image): ?>
                                        <a href="<?php echo e($actor->image_path); ?>">
                                            <img src="<?php echo e($actor->image_path); ?>" class="img-fluid my-2 img-thumbnail">

                                        </a>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>

            </div><!-- end of tile -->

        </div><!-- end of col -->

    </div><!-- end of row -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(function () {
            $('.image_path').each(function () { // the containers for all your galleries
                $(this).magnificPopup({
                    delegate: 'a', // the selector for gallery item
                    type: 'image',
                    gallery: {
                        enabled: true
                    }
                });
            });
        });


    </script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/movies/show.blade.php ENDPATH**/ ?>
<img src="<?php echo e($image_path); ?>" width="150px" height="200px">
<?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/actors/data_table/image.blade.php ENDPATH**/ ?>
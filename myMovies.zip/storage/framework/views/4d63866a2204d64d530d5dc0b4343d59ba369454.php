<!-- Sidebar menu-->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>

<aside class="app-sidebar">
    <div class="app-sidebar__user">
        <img class="app-sidebar__user-avatar" src="<?php echo e(auth()->user()->image_path); ?>" alt="User Image">
        <div>
            <p class="app-sidebar__user-name"><?php echo e(auth()->user()->name); ?></p>

        </div>
    </div>

    <ul class="app-menu">

        <li><a class="app-menu__item <?php echo e(request()->is('*home*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.home')); ?>"><i
                    class="app-menu__icon fa fa-home"></i> <span class="app-menu__label"><?php echo app('translator')->get('site.home'); ?></span></a>
        </li>

        
        <?php if(auth()->user()->hasPermission('read_roles')): ?>
            <li><a class="app-menu__item <?php echo e(request()->is('*roles*') ? 'active' : ''); ?>"
                   href="<?php echo e(route('admin.roles.index')); ?>"><i class="app-menu__icon fa fa-lock"></i> <span
                        class="app-menu__label"><?php echo app('translator')->get('roles.roles'); ?></span></a></li>
        <?php endif; ?>

        
        <?php if(auth()->user()->hasPermission('read_admins')): ?>
            <li><a class="app-menu__item <?php echo e(request()->is('*admins*') ? 'active' : ''); ?>"
                   href="<?php echo e(route('admin.admins.index')); ?>"><i class="app-menu__icon fa fa-users"></i> <span
                        class="app-menu__label"><?php echo app('translator')->get('admins.admins'); ?></span></a></li>
        <?php endif; ?>

        
        <?php if(auth()->user()->hasPermission('read_users')): ?>
            <li><a class="app-menu__item <?php echo e(request()->is('*users*') ? 'active' : ''); ?>"
                   href="<?php echo e(route('admin.users.index')); ?>"><i class="app-menu__icon fa fa-user"></i> <span
                        class="app-menu__label"><?php echo app('translator')->get('users.users'); ?></span></a></li>
        <?php endif; ?>



        
        <?php if(auth()->user()->hasPermission('read_genres')): ?>
            <li><a class="app-menu__item <?php echo e(request()->is('*genres*') ? 'active' : ''); ?>"
                   href="<?php echo e(route('admin.genres.index')); ?>"><i class="app-menu__icon fa fa-list"></i> <span
                        class="app-menu__label"><?php echo app('translator')->get('genres.genres'); ?></span></a></li>
        <?php endif; ?>


        
        <?php if(auth()->user()->hasPermission('read_movies')): ?>
            <li><a class="app-menu__item <?php echo e(request()->is('*movies*') ? 'active' : ''); ?>"
                   href="<?php echo e(route('admin.movies.index')); ?>"><i class="app-menu__icon fa fa-film"></i> <span
                        class="app-menu__label"><?php echo app('translator')->get('movies.movies'); ?></span></a></li>
        <?php endif; ?>


        

        <?php if(auth()->user()->hasPermission('read_actors')): ?>
            <li><a class="app-menu__item <?php echo e(request()->is('*actors*') ? 'active' : ''); ?>"
                   href="<?php echo e(route('admin.actors.index')); ?>"><i class="app-menu__icon fa fa-user-o"></i> <span
                        class="app-menu__label"><?php echo app('translator')->get('actors.actors'); ?></span></a></li>
        <?php endif; ?>


        
        <?php if(auth()->user()->hasPermission('read_settings')): ?>
            <li class="treeview <?php echo e(request()->is('*settings*') ? 'is-expanded' : ''); ?>"><a class="app-menu__item"
                                href="#"  data-toggle="treeview"><i
                        class="app-menu__icon fa fa-cogs"></i><span
                        class="app-menu__label"><?php echo app('translator')->get('settings.settings'); ?></span><i
                        class="treeview-indicator fa fa-angle-right"></i></a>

                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="<?php echo e(route('admin.settings.general')); ?>"><i
                                class="icon fa fa-circle-o"></i><?php echo app('translator')->get('settings.general'); ?></a></li>
                </ul>
            </li>
        <?php endif; ?>



        
        <li class="treeview <?php echo e(request()->is('*profile*') || request()->is('*password*')  ? 'is-expanded' : ''); ?>"><a
                class="app-menu__item" href="#" data-toggle="treeview"><i
                    class="app-menu__icon fa fa-user-circle"></i><span
                    class="app-menu__label"><?php echo app('translator')->get('users.profile'); ?></span><i
                    class="treeview-indicator fa fa-angle-right"></i></a>
            <ul class="treeview-menu">
                <li><a class="treeview-item" href="<?php echo e(route('admin.profile.edit')); ?>"><i
                            class="icon fa fa-circle-o"></i><?php echo app('translator')->get('users.edit_profile'); ?></a></li>
                <li><a class="treeview-item" href="<?php echo e(route('admin.profile.password.edit')); ?>"><i
                            class="icon fa fa-circle-o"></i><?php echo app('translator')->get('users.change_password'); ?></a></li>
            </ul>
        </li>


        
        
        
        

        
        
        
        


    </ul>
</aside>
<?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/layouts/admin/_aside.blade.php ENDPATH**/ ?>
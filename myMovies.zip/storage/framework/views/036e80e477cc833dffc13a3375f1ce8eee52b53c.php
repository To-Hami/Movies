<?php if(auth()->user()->hasPermission('update_admins')): ?>
    <a href="<?php echo e(route('admin.admins.edit', $id)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i> <?php echo app('translator')->get('site.edit'); ?></a>
<?php endif; ?>

<?php if(auth()->user()->hasPermission('delete_admins')): ?>
    <form action="<?php echo e(route('admin.admins.destroy', $id)); ?>" class="my-1 my-xl-0" method="post" style="display: inline-block;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <button type="submit" class="btn btn-danger btn-sm delete"><i class="fa fa-trash"></i> <?php echo app('translator')->get('site.delete'); ?></button>
    </form>
<?php endif; ?>
<?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/admins/data_table/actions.blade.php ENDPATH**/ ?>
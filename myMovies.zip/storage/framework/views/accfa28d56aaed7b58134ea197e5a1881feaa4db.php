

<?php $__env->startSection('content'); ?>

    <div>
        <h2><?php echo app('translator')->get('users.change_password'); ?></h2>
    </div>

    <ul class="breadcrumb mt-2">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
        <li class="breadcrumb-item"><?php echo app('translator')->get('users.change_password'); ?></li>
    </ul>

    <div class="row">

        <div class="col-md-12">

            <div class="tile shadow">

                <form method="post" action="<?php echo e(route('admin.profile.password.update')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>

                    <?php echo $__env->make('admin.partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('users.old_password'); ?></label>
                        <input type="password" name="old_password" class="form-control" value="" required>
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('users.password'); ?></label>
                        <input type="password" name="password" class="form-control" value="" required>
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('users.password_confirmation'); ?></label>
                        <input type="password" name="password_confirmation" class="form-control" value="" required>
                    </div>

                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-edit"></i> <?php echo app('translator')->get('site.edit'); ?></button>
                    </div>

                </form><!-- end of form -->

            </div><!-- end of tile -->

        </div><!-- end of col -->

    </div><!-- end of row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/profile/password/edit.blade.php ENDPATH**/ ?>
<i class="fa fa-star text-warning "></i><?php echo e($vote_Count); ?>

<?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/movies/data_table/vote_Count.blade.php ENDPATH**/ ?>
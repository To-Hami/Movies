<a href="<?php echo e(route('admin.movies.index',['actor_id'=>$id])); ?>" class="btn btn-primary btn-sm">Related Movies</a>

<?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/actors/data_table/related_movies.blade.php ENDPATH**/ ?>

<?php if(auth()->user()->hasPermission('delete_genres')): ?>
    <form action="<?php echo e(route('admin.genres.destroy', $id)); ?>" class="my-1 my-xl-0" method="post" style="display: inline-block;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <button type="submit" class="btn btn-danger btn-sm delete"><i class="fa fa-trash"></i> <?php echo app('translator')->get('site.delete'); ?></button>
    </form>
<?php endif; ?>
<?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/genres/data_table/actions.blade.php ENDPATH**/ ?>
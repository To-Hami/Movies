<?php $__env->startSection('content'); ?>

    <div>
        <h2><?php echo app('translator')->get('users.users'); ?></h2>
    </div>

    <ul class="breadcrumb mt-2">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.users.index')); ?>"><?php echo app('translator')->get('users.users'); ?></a></li>
        <li class="breadcrumb-item"><?php echo app('translator')->get('site.create'); ?></li>
    </ul>

    <div class="row">

        <div class="col-md-12">

            <div class="tile shadow">

                <form method="post" action="<?php echo e(route('admin.users.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('post'); ?>

                    <?php echo $__env->make('admin.partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('users.name'); ?> <span class="text-danger">*</span></label>
                        <input type="text" name="name" autofocus class="form-control" value="<?php echo e(old('name')); ?>" required>
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('users.email'); ?> <span class="text-danger">*</span></label>
                        <input type="email" name="email" autofocus class="form-control" value="<?php echo e(old('email')); ?>" required>
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('users.password'); ?> <span class="text-danger">*</span></label>
                        <input type="password" name="password" autofocus class="form-control" value="<?php echo e(old('password')); ?>" required>
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('users.password_confirmation'); ?> <span class="text-danger">*</span></label>
                        <input type="password" name="password_confirmation" autofocus class="form-control" value="<?php echo e(old('password_confirmation')); ?>" required>
                    </div>



                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i><?php echo app('translator')->get('site.create'); ?></button>
                    </div>

                </form><!-- end of form -->

            </div><!-- end of tile -->

        </div><!-- end of col -->

    </div><!-- end of row -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/users/create.blade.php ENDPATH**/ ?>
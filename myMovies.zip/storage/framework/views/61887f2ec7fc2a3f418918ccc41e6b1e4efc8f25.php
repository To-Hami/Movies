<?php $__env->startSection('content'); ?>

    <div>
        <h2><?php echo app('translator')->get('settings.settings'); ?></h2>
    </div>

    <ul class="breadcrumb mt-2">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
        <li class="breadcrumb-item"><?php echo app('translator')->get('settings.general_settings'); ?></li>
    </ul>

    <div class="row">

        <div class="col-md-12">

            <div class="tile shadow">

                <form method="post" action="<?php echo e(route('admin.settings.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('post'); ?>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('settings.logo'); ?></label>
                        <input type="file" name="logo" class="form-control load-image">
                        <img src="<?php echo e(Storage::url('uploads/' . setting('logo'))); ?>" class="loaded-image" alt="" style="display: <?php echo e(setting('logo') ? 'block' : 'none'); ?>; width: 100px; margin: 10px 0;">
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('settings.fav_icon'); ?></label>
                        <input type="file" name="fav_icon" class="form-control load-image">
                        <img src="<?php echo e(Storage::url('uploads/' . setting('fav_icon'))); ?>" class="loaded-image" alt="" style="display: <?php echo e(setting('fav_icon') ? 'block' : 'none'); ?>; width: 50px; margin: 10px 0;">
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('settings.title'); ?></label>
                        <input type="text" name="title" class="form-control" value="<?php echo e(setting('title')); ?>">
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('settings.description'); ?></label>
                        <textarea name="description" class="form-control"><?php echo e(setting('description')); ?></textarea>
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('settings.keywords'); ?></label>
                        <input type="text" name="keywords" class="form-control" value="<?php echo e(setting('keywords')); ?>">
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('users.email'); ?></label>
                        <input type="text" name="email" class="form-control" value="<?php echo e(setting('email')); ?>">
                    </div>

                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-edit"></i> <?php echo app('translator')->get('site.update'); ?></button>
                    </div>

                </form><!-- end of form -->

            </div><!-- end of tile -->

        </div><!-- end of col -->

    </div><!-- end of row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/settings/general.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>

    <div>
        <h2><?php echo app('translator')->get('admins.admins'); ?></h2>
    </div>

    <ul class="breadcrumb mt-2">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.admins.index')); ?>"><?php echo app('translator')->get('admins.admins'); ?></a></li>
        <li class="breadcrumb-item"><?php echo app('translator')->get('site.create'); ?></li>
    </ul>

    <div class="row">

        <div class="col-md-12">

            <div class="tile shadow">

                <form method="post" action="<?php echo e(route('admin.admins.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('post'); ?>

                    <?php echo $__env->make('admin.partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('users.name'); ?> <span class="text-danger">*</span></label>
                        <input type="text" name="name" autofocus class="form-control" value="<?php echo e(old('name')); ?>" required>
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('users.email'); ?> <span class="text-danger">*</span></label>
                        <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" required>
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('users.password'); ?> <span class="text-danger">*</span></label>
                        <input type="password" name="password" class="form-control" value="" required>
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('users.password_confirmation'); ?> <span class="text-danger">*</span></label>
                        <input type="password" name="password_confirmation" class="form-control" value="" required>
                    </div>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('roles.role'); ?> <span class="text-danger">*</span></label>
                        <select name="role_id" class="form-control select2" required>
                            <option value=""><?php echo app('translator')->get('site.choose'); ?> <?php echo app('translator')->get('roles.role'); ?></option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->id); ?>" <?php echo e($role->id == old('role_id') ? 'selected' : ''); ?>><?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i><?php echo app('translator')->get('site.create'); ?></button>
                    </div>

                </form><!-- end of form -->

            </div><!-- end of tile -->

        </div><!-- end of col -->

    </div><!-- end of row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/admins/create.blade.php ENDPATH**/ ?>
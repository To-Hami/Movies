<a href="<?php echo e(route('admin.movies.index',['genre_id'=>$id])); ?>" class="btn btn-primary btn-sm">Related Movies</a>

<?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/genres/data_table/movies.blade.php ENDPATH**/ ?>
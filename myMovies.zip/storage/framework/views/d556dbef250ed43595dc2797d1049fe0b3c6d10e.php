

<?php $__env->startSection('content'); ?>

    <div>
        <h2><?php echo app('translator')->get('roles.roles'); ?></h2>
    </div>

    <ul class="breadcrumb mt-2">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo app('translator')->get('site.home'); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.roles.index')); ?>"><?php echo app('translator')->get('roles.roles'); ?></a></li>
        <li class="breadcrumb-item"><?php echo app('translator')->get('site.create'); ?></li>
    </ul>

    <div class="row">

        <div class="col-md-12">

            <div class="tile shadow">

                <form method="post" action="<?php echo e(route('admin.roles.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('post'); ?>

                    <?php echo $__env->make('admin.partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    
                    <div class="form-group">
                        <label><?php echo app('translator')->get('roles.name'); ?> <span class="text-danger">*</span></label>
                        <input type="text" name="name" autofocus class="form-control" value="<?php echo e(old('name')); ?>" required>
                    </div>

                    <h5><?php echo app('translator')->get('roles.permissions'); ?> <span class="text-danger">*</span></h5>

                    <?php
                        $models = ['roles', 'admins'];
                    ?>

                    <table class="table">
                        <thead>
                        <tr>
                            <th><?php echo app('translator')->get('roles.model'); ?></th>
                            <th><?php echo app('translator')->get('roles.permissions'); ?></th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo app('translator')->get($model . '.' . $model); ?></td>
                                <td>
                                    <div class="animated-checkbox mx-2" style="display:inline-block;">
                                        <label class="m-0">
                                            <input type="checkbox" value="" name="" class="all-roles">
                                            <span class="label-text"><?php echo app('translator')->get('site.all'); ?></span>
                                        </label>
                                    </div>

                                    <?php
                                        //create_roles, read_roles, update_roles, delete_roles
                                            $permissionMaps = ['create', 'read', 'update', 'delete'];
                                    ?>

                                    <?php $__currentLoopData = $permissionMaps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissionMap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="animated-checkbox mx-2" style="display:inline-block;">
                                            <label class="m-0">
                                                <input type="checkbox" value="<?php echo e($permissionMap . '_' . $model); ?>" name="permissions[]" class="role">
                                                <span class="label-text"><?php echo app('translator')->get('site.' . $permissionMap); ?></span>
                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table><!-- end of table -->

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i><?php echo app('translator')->get('site.create'); ?></button>
                    </div>

                </form><!-- end of form -->

            </div><!-- end of tile -->

        </div><!-- end of col -->

    </div><!-- end of row -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/roles/create.blade.php ENDPATH**/ ?>
<div id="movies_chart"> </div>
<script>

       var options = {
           chart: {
               type: 'bar',
               height:300
           },
           plotOptions:{
               bar:{
                   columnWidth:'50%',
                   borderRadius:40
               }
           },
           series: [{
               name: '<?php echo app('translator')->get('movies.total_movies'); ?>',
               data: <?php echo json_encode($movies->pluck('total_movies')->toArray(), 15, 512) ?>
           }],
           xaxis: {
               categories: <?php echo json_encode($movies->pluck('month')->toArray(), 15, 512) ?>
           }
       };

       var movies_chart = new ApexCharts(document.querySelector("#movies_chart"), options);

       movies_chart.render();


</script>
<?php /**PATH C:\xampp8\htdocs\myMovies\resources\views/admin/_movies_chart.blade.php ENDPATH**/ ?>
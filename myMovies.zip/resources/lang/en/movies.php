<?php

return [
    'movies' => 'Movies',
    'name' => 'Name',
    'movie' => 'Movie',
    'title' => 'Title',
    'description' => 'Description',
    'vote' => 'Vote',
    'vote_count' => 'Vote count',
    'release_date' => 'Release date',
    'poster' => 'Poster',
    'banner' => 'Banner',
    'now_playing' => 'Now playing movies',
    'upcoming' => 'Upcoming movies',
    'by' => 'By',
    'language' => 'Language',
    'movies_chart' => 'Movies chart',
    'total_movies' => 'Total movies',
    'top' => 'Top',
    'popular' => 'Popular movies',
    'favourite_by' => 'Favourite by',
];

<?php

return [
    'admins' => 'Admins',
    'admin' => 'Admin',
];
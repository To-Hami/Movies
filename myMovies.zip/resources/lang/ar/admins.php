<?php

return [
    'admins' => 'المشرفون',
    'admin' => 'المشرف',
];
<?php

return [
    'users' => 'المستخدمين',
    'user' => 'المستخدم',
    'name' => 'الاسم',
    'email' => 'البريد الإلكتروني',
    'password' => 'الرقم السري',
    'password_confirmation' => 'تأكيد الرقم السري',
    'profile' => 'الملف الشخصي',
    'change_password' => 'تغيير الرقم السري',
    'old_password' => 'الرقم السري القديم',
    'incorrect_old_password' => 'رقم سري قديم غير صحيح',
    'edit_profile' => 'تعديل الملف الشخصي',
];